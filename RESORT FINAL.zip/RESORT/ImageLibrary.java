import java.awt.image.*;
import javax.imageio.*;
import java.io.*;
import javax.swing.ImageIcon;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;


/**
 * Write a description of class ImageLibrary here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ImageLibrary
{
      
        
        
        //Forbackgrounds
         ImageIcon titlepage = new ImageIcon("ImgLib/Titlepage.png");
         ImageIcon mmfbg = new ImageIcon("ImgLib/Mmf.png");
         ImageIcon staffbg = new ImageIcon("ImgLib/Staffr.png");
         ImageIcon addcbg = new ImageIcon("ImgLib/Course.png");
         ImageIcon calendar = new ImageIcon("ImgLib/Calender.png");
         ImageIcon editdbg = new ImageIcon("ImgLib/EditDepartment.png");
         ImageIcon editcbg = new ImageIcon("ImgLib/EditCourse.png");
         ImageIcon editcbg2 = new ImageIcon("ImgLib/EditCourse2.png");
         ImageIcon editpbg = new ImageIcon("ImgLib/EditProgram.png");
         
     
         
         
         
    }
    
   

